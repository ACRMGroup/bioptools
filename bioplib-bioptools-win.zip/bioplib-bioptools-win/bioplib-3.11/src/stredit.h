int blLevenshteinDistance(char *s, char *t);
