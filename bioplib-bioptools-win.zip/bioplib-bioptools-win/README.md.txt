Add to PATH environment variables, on Windows11: 
Open Control Panel > System and Security > Edit the system environment variables 

This opens a new window called "System Properties"
At the bottom click on "Environment Variables ..."

In the new window
Under "System variables" > find and click "Path" from the list > click "Edit ..."

In the new window 
click "New" (the first button on the right side panel) 
copy and paste the path to "\some\path\to\bioptools-1.10\src"
for example "C:\Users\username\Downloads\bioplib-bioptools-win\bioptools-1.10\src"
Now bioptools program e.g. pdbsolv should be ready to use on Command Prompt by typing "pdbsolv"

To run bioptool programs e.g. pdbsolv 
open a "Command Prompt", change to directory "bioplib-bioptools-win", e.g.
> cd C:\Users\username\Downloads\bioplib-bioptools-win\test-pdb-file
> pdbsolv 12e8.pdb 
This should print results to your terminal 
for usage run the following, same applies to other programs e.g. pdbsecstr  
> pdbsolv -h 